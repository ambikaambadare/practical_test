<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_model extends CI_Model {

    public function save_data($data)
    {
        $this->db->insert('employee_details',$data);
        return $this->db->insert_id();
    }

    public function fetch_data()
    {
        return $this->db->get('employee_details')->result_array();       
    }

    public function edit_data($id)
    {
        return $this->db->where('id', $id)->get('employee_details')->row();       
    }

    public function update_data($data,$id)
    {
        $this->db->where('id',$id);
        return $this->db->update('employee_details',$data);
        
    }

    public function delete_data($id)
    {
        $this->db->where('id',$id);
        return $this->db->delete('employee_details');
        
    }
    
    

}