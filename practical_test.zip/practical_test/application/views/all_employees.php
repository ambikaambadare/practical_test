<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<link href="<?php echo base_url('assets/css_js/bootstrap.min.css'); ?>" rel="stylesheet">
	
	<style>
	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div style="padding:5px;">
		<h5 style="text-align:center;">Employee Details</h5> 
		<br></br>
		<a href="<?php echo base_url('Welcome'); ?>" class="btn btn-xs btn-primary" >Add New Employee  </a>
       <?php 
                    if(isset($_GET['alert']))
                    { 
                        if($_GET['alert'] == 'ok')
                        {
            ?>
            <div style="color:green;" >Employee data saved successfully..</div>
            <?php }else if($_GET['alert'] == 'dok')
                        {
            ?>
            <div style="color:green;" >Employee data deleted successfully..</div>
            <?php }else if($_GET['alert'] == 'uok')
                        {
            ?>
            <div style="color:green;" >Employee data updated successfully..</div>
            <?php }else{ ?>
                <div style="color:red;" >Employee data not saved</div>
           <?php }  }?>
	<br><br>

    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email</th>
      <th scope="col">Mobile</th>
      <th scope="col">Address</th>
      <th scope="col">Gender</th>
      <th scope="col">Hobby</th>
      <th scope="col">Photo</th>
      <th scope="col">Created Date</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php 
        $i = 1;       
        foreach($all_details as $key){ ?>
    <tr>
      <th scope="row"><?php echo $i++; ?></th>
      <td><?php echo $key['firstname']; ?></td>
      <td><?php echo $key['lastname']; ?></td>
      <td><?php echo $key['emailid']; ?></td>
      <td><?php echo $key['cnt_code'].$key['mobileno']; ?></td>
      <td><?php echo $key['address']; ?></td>
      <td> <?php if($key['gender'] == 'M'){ echo 'Male'; }else{ echo "Female";}  ?> </td>
      <td><?php if($key['hobby'] == 'Y'){ echo 'Yes'; }else{ echo "-";}  ?></td>      
      <td><a href="<?php echo base_url('assets/uploads/') ?><?php echo $key['photo_file']; ?>" target="_blank"><img style="width:60px;height:70px" src="<?php echo base_url('assets/uploads/') ?><?php echo $key['photo_file']; ?>"></a></td>
      <td><?php echo date('d/m/Y',strtotime($key['created_at'])); ?></td>
      <td><a class="btn btn-xs btn-info" href="<?php echo base_url('edit_data/') ?><?php echo $key['id']; ?>">Edit</a>
      <a class="btn btn-xs btn-danger" href="<?php echo base_url('delete_data/') ?><?php echo $key['id']; ?>" onclick="return confirm('Are you want to delete this employee ?')" >Delete</a></td>
    </tr>
    <?php  } ?>
  </tbody>
</table>
				
</div>
<script src="<?php echo base_url('assets/css_js/bootstrap.min.js'); ?>" >
	<script src="<?php echo base_url('assets/css_js/jquery-3.5.1.slim.min.js'); ?>">
    
</body>
</html>