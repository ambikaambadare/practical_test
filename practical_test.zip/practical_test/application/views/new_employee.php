<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<link href="<?php echo base_url('assets/css_js/bootstrap.min.css'); ?>" rel="stylesheet">
	
	<style>
	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div style="padding:5px;">
		<h5 style="text-align:center;">Add New Employee <?php echo $this->session->set_flashdata('success'); ?></h5> 
		<br></br>
		<a href="<?php echo base_url('fetch_data'); ?>" class="btn btn-xs btn-primary" >Employee Details</a> 
		<?php 
                    if(isset($_GET['alert']))
                    { 
                        if($_GET['alert'] == 'ok')
                        {
            ?>
            <div style="color:green;" >Employee data saved successfully..</div>
            <?php }else if($_GET['alert'] == 'dok')
                        {
            ?>
            <div style="color:green;" >Employee data deleted successfully..</div>
            <?php }else if($_GET['alert'] == 'uok')
                        {
            ?>
            <div style="color:green;" >Employee data deleted successfully..</div>
            <?php }else{ ?>
                <div style="color:red;" >Employee data not saved</div>
           <?php }  }?>
	<br><br>
		<form method="POST" action="<?php echo base_url('save_data'); ?>" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-1">
				<label>First Name</label>
			</div>
			<div class="col-md-4">
				<input type="text" name="firstname" class="form-control" required>
			</div>
			<div class="col-md-1">
				<label>Last Name</label>
			</div>
			<div class="col-md-4">
				<input type="text" name="lastname" class="form-control" required>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-1">
				<label>Email</label>
			</div>
			<div class="col-md-4">
				<input type="email" name="emailid" class="form-control" required>
			</div>
			<div class="col-md-1">
				<label>Mobile</label>
			</div>
			<div class="col-md-1">
				<select name="cnt_code" class="form-control" required>
					<option value="">--</option>
					<option value="+91">+91</option>					
				</select>
			</div>
			<div class="col-md-3">
				<input type="number" name="mobileno" class="form-control"  required>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-1">
				<label>Address</label>
			</div>
			<div class="col-md-4">
				<textarea name="address" class="form-control" required></textarea>				
			</div>
			<div class="col-md-1">
				<label>Gender</label>
			</div>
			<div class="col-md-1">
				<input type="radio" name="gender" value="M" required>Male				
			</div>
			<div class="col-md-2">				
				<input type="radio" name="gender" value="F" required>Female
			</div>
		</div><br>
		<div class="row">
			<div class="col-md-1">
				<label>Hobby</label>
			</div>
			<div class="col-md-4">
				<input type="checkbox" name="hobby" value="Y" required>
			</div>
			<div class="col-md-1">
				<label>Photo</label>
			</div>
			<div class="col-md-4">
				<input type="file" name="file" required>
			</div>
			
			<div class="col-md-12" style="text-align:center;">
			<br>
				<input  type="submit" name="submit" value="Submit" class="btn btn-xs btn-success">
				
			</div>
		</div>	
		
	</form>
</div>
<script src="<?php echo base_url('assets/css_js/bootstrap.min.js'); ?>" >
<script src="<?php echo base_url('assets/css_js/jquery-3.5.1.slim.min.js'); ?>">
<script>
		document.getElementById('alertdiv');

		function hideMydiv{
			div.classList.add('hidden');
		}
		setTimeout(hideMydiv,5000);
</script>
</body>
</html>