<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Employee_model', 'empmodel');
	}
	
	public function index()
	{
		$this->load->view('new_employee');
	}

	public function save_data()
	{
		$result ='';
		$config['upload_path'] = './assets/uploads/';
		$config['allowed_types'] = '*';
		$config['max_size'] = '2048';
		$config['encrypt_name'] = TRUE;

		$this->upload->initialize($config);

		if($this->upload->do_upload('file'))
		{
			$photois = $this->upload->data();
			$photopath = $photois['file_name'];		
			
			$data = array(
							'firstname' =>$this->input->post('firstname'),
							'lastname' =>$this->input->post('lastname'),
							'emailid' =>$this->input->post('emailid'),
							'cnt_code' =>$this->input->post('cnt_code'),
							'mobileno' =>$this->input->post('mobileno'),
							'address' =>$this->input->post('address'),
							'gender' =>$this->input->post('gender'),
							'hobby' =>$this->input->post('hobby'),
							'photo_file' =>$photopath
						);
			
			$result = $this->empmodel->save_data($data);	
			
		}
		
		if($result)
		{
			redirect('fetch_data?alert=ok');
		}
		else
		{
			redirect('Welcome?alert=notok');
		}

	}

	public function fetch_data()
	{
		$data['all_details'] = $this->empmodel->fetch_data();		
		$this->load->view('all_employees',$data);
	}

	public function edit_data($id)
	{
		$data['edit'] = $this->empmodel->edit_data($id);		
		$this->load->view('edit_employee',$data);
	}

	public function update_data()
	{
		$result ='';
		$config['upload_path'] = './assets/uploads/';
		$config['allowed_types'] = '*';
		$config['max_size'] = '2048';
		$config['encrypt_name'] = TRUE;

		$this->upload->initialize($config);

		$id = $this->input->post('id');

		if($this->upload->do_upload('file'))
		{
			$photois = $this->upload->data();
			$photopath = $photois['file_name'];		
			
			$data = array(
							'firstname' =>$this->input->post('firstname'),
							'lastname' =>$this->input->post('lastname'),
							'emailid' =>$this->input->post('emailid'),
							'cnt_code' =>$this->input->post('cnt_code'),
							'mobileno' =>$this->input->post('mobileno'),
							'address' =>$this->input->post('address'),
							'gender' =>$this->input->post('gender'),
							'hobby' =>$this->input->post('hobby'),
							'photo_file' =>$photopath
						);
			
			$result = $this->empmodel->update_data($data,$id);
		}
		else
		{
			$data = array(
				'firstname' =>$this->input->post('firstname'),
				'lastname' =>$this->input->post('lastname'),
				'emailid' =>$this->input->post('emailid'),
				'cnt_code' =>$this->input->post('cnt_code'),
				'mobileno' =>$this->input->post('mobileno'),
				'address' =>$this->input->post('address'),
				'gender' =>$this->input->post('gender'),
				'hobby' =>$this->input->post('hobby'),				
			);

			$result = $this->empmodel->update_data($data,$id);
		}	
		
		if($result)
		{
			redirect('fetch_data?alert=uok');
		}
		else
		{
			redirect('edit_data/'.$id.'/?alert=notok');
		}
	}

	public function delete_data($id)
	{
		$result = $this->empmodel->delete_data($id);	
		if($result)
		{
			redirect('fetch_data?alert=dok');
		}
		else
		{
			redirect('fetch_data?alert=notok');
		}	
		
	}




}
